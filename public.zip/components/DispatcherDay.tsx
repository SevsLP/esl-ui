"use client";

export default function DispatcherDay() {
  return (
    <div style={{ padding: 16 }}>
      <h2 style={{ margin: 0, fontSize: 16 }}>
        {"\u0414\u0438\u0441\u043f\u0435\u0442\u0447\u0435\u0440 \u2014 \u0414\u0435\u043d\u044c"}
      </h2>

      <div style={{ marginTop: 10, opacity: 0.75 }}>
        {"\u0417\u0434\u0435\u0441\u044c \u0431\u0443\u0434\u0435\u0442 \u0442\u0430\u0431\u043b\u0438\u0446\u0430 \u0434\u0438\u0441\u043f\u0435\u0442\u0447\u0435\u0440\u0430."}
      </div>
    </div>
  );
}