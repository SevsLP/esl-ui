"use client";

import { useEffect, useMemo, useState } from "react";
import DispatcherDay from "../../components/DispatcherDay";
import DriverScheduleWeek from "../../components/DriverScheduleWeek";
import { supabase } from "../../lib/supabaseClient";

type TabKey = "day" | "schedule";

const TXT = {
  tab_day: "\u0414\u0435\u043d\u044c",
  tab_schedule: "\u0413\u0440\u0430\u0444\u0438\u043a \u0432\u043e\u0434\u0438\u0442\u0435\u043b\u0435\u0439",
};

function tabBtnStyle(active: boolean): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 10,
    border: active ? "1px solid rgba(200, 122, 30, 0.55)" : "1px solid #2a2a2a",
    background: active ? "rgba(200, 122, 30, 0.10)" : "#0f0f0f",
    color: "#fff",
    cursor: "pointer",
    fontWeight: 800,
    boxShadow: active ? "0 0 18px rgba(200, 122, 30, 0.10)" : "none",
  };
}

export default function Page() {
  const [tab, setTab] = useState<TabKey>("day");

  // Автоприменение планов увольнения/восстановления (без cron)
  useEffect(() => {
    const run = async () => {
      try {
        await supabase.rpc("apply_driver_employment_plans");
      } catch {
        // игнорируем: экран не должен падать, если RPC временно недоступен
      }
    };

    run();
  }, []);

  const content = useMemo(() => {
    if (tab === "schedule") return <DriverScheduleWeek />;
    return <DispatcherDay />;
  }, [tab]);

  return (
    <div style={{ padding: 18 }}>
      <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 14 }}>
        <button style={tabBtnStyle(tab === "day")} onClick={() => setTab("day")}>
          {TXT.tab_day}
        </button>
        <button style={tabBtnStyle(tab === "schedule")} onClick={() => setTab("schedule")}>
          {TXT.tab_schedule}
        </button>
      </div>

      {content}
    </div>
  );
}
